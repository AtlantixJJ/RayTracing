#ifndef PHOTONMAP_H
#define PHOTONMAP_H

#include "common/common.h"

#include <queue>
#include <vector>

class Intersection;
/**
*   Photon Map.
**/
class PhotonMap
{
public:
    PhotonMap()
        : _n(0), _plane(nullptr), _photons(nullptr) {}
    ~PhotonMap();

    void addPhoton(const Photon& photon) {
        //if(DEBUG >= 1) printf("add a photon\n");
        _buffer.push_back(photon);
    }

    Color getIrradiance(const Intersection& coll, int samples);

    void build();

private:
    int _n;
    unsigned char* _plane;
    Photon* _photons;
    std::vector<Photon> _buffer;
    std::priority_queue<pair<double, int>> _pq;

    int _samples; // 最近的光子数
    Vector3 _pos; // 询问点

    // 建 KD-tree
    void _build(int l, int r);

    // 找最近 _samples 个光子
    void _findNearestPhotons(int l, int r);
};

#endif // PHOTONMAP_H
