#include "utils/config.h"
#include "common/const.h"
#include "engine/photonmapper/photonmap.h"
#include "engine/photonmapper/photontracer.h"
#include "engine/ppm/hitpointmap.h"
#include "light/light.h"
#include "object/material.h"
#include "object/object.h"
#include "env/scene.h"
#include <unistd.h>
#include "omp.h"
using namespace std;

void PhotonTracer::emitPhotons(int photonNumber)
{
    double power = 0, lp = 0;
    int tot = 0;
    Photon ph;

    for( auto l = _scene->lightsBegin(); l != _scene -> lightsEnd(); l++)
    {
        //printf("%d\n",*l);
        power += (*l)->getColor().power();
    }
    //printf("%d\n",gconf);
    power /= photonNumber;    
    int i;

    #pragma omp parallel for
    for(i=0;i<5;i++)
        printf("%d\n",i);
#ifdef MULTITHREAD
    #pragma omp parallel num_threads(4)
#endif
    for( i = 0 ; i < _scene->getLightSourceNum() ; i++)
    {
        Light *l = _scene->getLightbyInd(i);
        lp = l->getColor().power();
        for (; lp > 0; lp -= power)
        {
            ph = l->emitPhoton(power);
            //printf("%lf\n",ph.pow.power());
            _photonTracing(ph, 1, false);
            //omp_set_lock(&lock);
            //sleep(1);
            //printf("tot%d\n",tot);
            if (++tot % 1000 == 0) printf( "Emitted %d photons.\n",tot);
            //omp_unset_lock(&lock);
            //sleep(1);
        }
    }
}

void PhotonTracer::_photonTracing(Photon& photon, int depth, bool isInternal)
{
    if (depth > Config::phtrace_max_depth) return;

    Intersection coll = _scene->findNearestIntersection(Ray(photon.pos, photon.dir));
    if (coll.isHit() && coll.atObject())
    {
        photon.pos = coll.p;
        const Object* obj = coll.getObject();
        const Material* material = obj->getMaterial();
        if (material->diff > Const::EPS)
        {
            if (_photon_map) _photon_map->addPhoton(photon);
            if (_hit_point_map) _hit_point_map->incomingPhoton(photon);
        }

        Color cd = material->color * obj->getTextureColor(coll), ct(1, 1, 1);
        if (isInternal) // 透明材质的颜色过滤
        {
            Color absorb = (material->absorb_color * -coll.dist).exp();
            cd *= absorb, ct *= absorb;
        }
        double fortune = randDouble;
        double pd = (material->diff + material->spec) * cd.power(), // 漫反射概率
            ps = material->refl * cd.power(),                       // 镜面反射概率
            pt = material->refr * ct.power();                       // 透射概率

        if (fortune < pd) // 漫反射
        {
            photon.dir = coll.n.diffuse();
            photon.pow *= cd / cd.power();
            _photonTracing(photon, depth + 1, isInternal);
        }
        else if (fortune < pd + ps) // 镜面反射
        {
            photon.dir = coll.ray.dir.reflect(coll.n);
            photon.pow *= cd / cd.power();
            _photonTracing(photon, depth + 1, isInternal);
        }
        else if (fortune < pd + ps + pt) // 透射
        {
            double n = material->rindex;
            if (isInternal) n = 1 / n;
            photon.dir = coll.ray.dir.refract(coll.n, n);
            photon.pow *= ct / ct.power();
            _photonTracing(photon, depth + 1, !isInternal);
        }
    }
}
