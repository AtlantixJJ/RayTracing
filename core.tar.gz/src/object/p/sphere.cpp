#include "common/const.h"
#include "object/sphere.h"

Sphere::Sphere(const Vector3& o, double r, const Material* m)
    : Object(m), _o(o), _r(r),
      _dz(0, 0, 1), _dx(1, 0, 0)
{
}

Sphere::Sphere(const Json::Value& object)
    : Object(object), _o(object["o"]), _r(object["r"].asDouble()),
      _dz(object["texture_dz"]), _dx(object["texture_dx"])
{
}

Intersection Sphere::collide(const Ray& ray) const
{
    Ray uray = ray.normalize();
    Vector3 oc = _o - ray.start;
    double tca = oc.dot(uray.dir), thc2 = _r * _r - oc.mod2() + tca * tca;
    if (thc2 >= 0)
    {
        double thc = sqrt(thc2), t1 = tca - thc, t2 = tca + thc;
        if (t1 > Const::EPS)
        {
            Vector3 p = uray.get(t1);
            return Intersection(uray, t1, p - _o, this, false);
        }
        else if (t2 > Const::EPS)
        {
            Vector3 p = uray.get(t2);
            return Intersection(uray, t2, _o - p, this, true);
        }
    }

    return Intersection();
}

Color Sphere::getTextureColor(const Intersection& coll) const
{
    if (_material->hasTexture())
    {
        double b = acos(coll.n.dot(_dz)), a = acos(std::min(std::max(coll.n.dot(_dx) / sin(b), -1.0), 1.0));
        double v = b / Const::PI, u = a / 2 / Const::PI;
        if (coll.n.dot(_dz * _dx) < 0) u = 1 - u;
        return _material->getTextureColor(u, v);
    }
    else
        return Color(1, 1, 1);
}

Json::Value Sphere::toJson() const
{
    Json::Value object = Object::toJson();
    object["type"] = "Sphere";
    object["o"] = _o.toJson();
    object["r"] = _r;
    if (_material->hasTexture())
    {
        object["texture_dz"] = _dz.toJson();
        object["texture_dx"] = _dx.toJson();
    }
    return object;
}
