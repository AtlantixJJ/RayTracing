#include "common/const.h"
#include "object/cylinder.h"

Cylinder::Cylinder(const Vector3& o, double r, double h, const Material* m)
    : Object(m), _o(o), _r(r), _h(h),
      _arg(0)
{
}

Cylinder::Cylinder(const Json::Value& object)
    : Object(object), _o(object["o"]), _r(object["r"].asDouble()), _h(object["h"].asDouble()),
      _arg(fmod(object["texture_arg"].asDouble() / 180 * Const::PI, 2 * Const::PI))
{
}

Intersection Cylinder::collide(const Ray& ray) const
{
    Ray uray = ray.normalize();
    Vector3 d3 = uray.dir;
    Point2D d2(d3.x, d3.y), oc = Point2D(_o.x - ray.start.x, _o.y - ray.start.y);
    double t = -1;
    bool in = _o.z < ray.start.z + Const::EPS && ray.start.z < _o.z + _h + Const::EPS && oc.mod2() < _r * _r + Const::EPS;

    // 与两个底面求交
    if (abs(d3.z) > -Const::EPS)
    {
        double t1 = (_o.z - ray.start.z) / d3.z, t2 = (_o.z + _h - ray.start.z) / d3.z, u1 = 0, u2 = 1;
        if (t1 > t2) swap(t1, t2), swap(u1, u2);
        if (t1 > Const::EPS) // 若射线和第一个底面相交，直接返回
        {
            Vector3 p = uray.get(t1);
            Point2D q = (p - _o).toPoint2D();
            if (q.mod2() < _r * _r + Const::EPS)
                return Intersection(uray, t1, u1, q.arg(), Vector3(0, 0, -d3.z), this, in);
        }
        else if (t2 > Const::EPS) // 若射线和第二个底面相交，且射线起点在圆柱体内，也直接返回
        {
            Vector3 p = uray.get(t2);
            Point2D q = (p - _o).toPoint2D();
            if (q.mod2() < _r * _r + Const::EPS && in)
                return Intersection(uray, t2, u2, q.arg(), Vector3(0, 0, -d3.z), this, in);
        }
        else // 若射线不和上下底面所在的平面相交，则无交点
            return Intersection();
    }

    // 若射线垂直于 xy 平面，则交点不会在圆柱面上
    if (d2.mod2() < Const::EPS && t < 0) return Intersection();

    // 否则第一个交点为圆柱面
    double tca = oc.dot(d2.normalize()), thc2 = _r * _r - oc.mod2() + tca * tca;
    if (thc2 >= 0)
    {
        double thc = sqrt(thc2), t1 = tca - thc, t2 = tca + thc;
        if (t1 > Const::EPS)
            t = t1;
        else
            t = t2;
    }
    if (t > Const::EPS)
    {
        t /= d2.mod();
        Vector3 p = uray.get(t);
        if (_o.z < p.z + Const::EPS && p.z < _o.z + _h + Const::EPS)
            return Intersection(uray, t, (p.z - _o.z) / _h, (p - _o).toPoint2D().arg(),
                             Vector3(p.x - _o.x, p.y - _o.y, 0) * (in ? -1 : 1), this, in);
    }
    return Intersection();
}

Color Cylinder::getTextureColor(const Intersection& coll) const
{
    if (_material->hasTexture())
    {
        double u = fmod(coll.v - _arg + 4 * Const::PI, 2 * Const::PI) / 2 / Const::PI,
               v = 1 - coll.u;
        return _material->getTextureColor(u, v);
    }
    else
        return Color(1, 1, 1);
}

Json::Value Cylinder::toJson() const
{
    Json::Value object = Object::toJson();
    object["type"] = "Cylinder";
    object["o"] = _o.toJson();
    object["r"] = _r;
    object["h"] = _h;
    if (_material->hasTexture()) object["texture_arg"] = _arg * 180 / Const::PI;
    return object;
}
