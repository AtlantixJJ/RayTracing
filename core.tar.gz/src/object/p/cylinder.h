#ifndef CYLINDER_H
#define CYLINDER_H

#include "math/vector3.h"
#include "object/object.h"

class Cylinder : public Object
{
public:
    Cylinder(const Vector3& o, double r, double h, const Material* m = nullptr);
    Cylinder(const Json::Value& object);

    virtual std::string getType() const override { return "Cylinder"; }

    // 与视线相交
    virtual Intersection collide(const Ray& ray) const override;

    // 交点处的纹理颜色
    virtual Color getTextureColor(const Intersection& coll) const override;

    virtual Json::Value toJson() const override;

    // 设置纹理起点极角
    void setTextureArg(double a) { _arg = a; }

private:
    Vector3 _o;            // 底面圆心
    double _r, _h, _arg; // 底面半径，高，纹理起点极角
};

#endif // CYLINDER_H
