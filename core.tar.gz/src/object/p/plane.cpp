#include "common/const.h"
#include "object/plane.h"

Plane::Plane(const Vector3& n, double d, const Material* m)
    : Object(m), _n(n.normalize()), _d(d),
      _o(0, 0, 0), _dx(n.getAnVerticalVector()), _dy((n * _dx).normalize())
{
}

Plane::Plane(const Json::Value& object)
    : Object(object), _n(object["n"]), _d(object["d"].asDouble()),
      _o(object["texture_o"]), _dx(object["texture_dx"]), _dy(object["texture_dy"])
{
}

Intersection Plane::collide(const Ray& ray) const
{
    double n = _n.dot(ray.start) + _d, d = _n.dot(ray.dir);
    if (abs(d) < Const::EPS) return Intersection();
    double t = -n / d;
    if (t < Const::EPS) return Intersection();
    if (n > Const::EPS)
        return Intersection(ray, t, _n, this);
    else
        return Intersection(ray, t, -_n, this);
}

Color Plane::getTextureColor(const Intersection& coll) const
{
    if (_material->hasTexture())
    {
        double u = (coll.p - _o).dot(_dx) / _dx.mod2(),
               v = (coll.p - _o).dot(_dy) / _dy.mod2();
        u -= floor(u), v -= floor(v);
        return _material->getTextureColor(u, v);
    }
    else
        return Color(1, 1, 1);
}

Json::Value Plane::toJson() const
{
    Json::Value object = Object::toJson();
    object["type"] = "Plane";
    object["n"] = _n.toJson();
    object["d"] = _d;
    if (_material->hasTexture())
    {
        object["texture_o"] = _o.toJson();
        object["texture_dx"] = _dx.toJson();
        object["texture_dy"] = _dy.toJson();
    }
    return object;
}
