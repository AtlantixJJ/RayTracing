#ifndef SPHERE_H
#define SPHERE_H

#include "math/vector3.h"
#include "object/object.h"

class Sphere : public Object
{
public:
    Sphere(const Vector3& o, double r, const Material* m = nullptr);
    Sphere(const Json::Value& object);

    virtual std::string getType() const override { return "Sphere"; }

    // 与视线相交
    virtual Intersection collide(const Ray& ray) const override;

    // 交点处的纹理颜色
    virtual Color getTextureColor(const Intersection& coll) const override;

    virtual Json::Value toJson() const override;

    // 设置纹理坐标轴
    void setTextureAxis(const Vector3& dz, const Vector3& dx) { _dz = dz, _dx = dx; }

private:
    Vector3 _o;        // 球心
    double _r;         // 半径
    Vector3 _dz, _dx; // 北极向量和 0 度经线方向
};

#endif // SPHERE_H
